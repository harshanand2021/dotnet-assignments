﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_1
{
    internal class Student
    {
        // Backing fields
        private int _rollNo;
        private string _name;
        private double _marks;

        // Properties
        public int RollNo
        {
            get { return _rollNo; }
            set { _rollNo = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public double Marks
        {
            get { return _marks; }
            set { _marks = value; }
        }

        // Display Method
        public void Display()
        {
            Console.WriteLine($"--- Student Details ---");
            Console.WriteLine($"Roll No: {RollNo}");
            Console.WriteLine($"Name   : {Name}");
            Console.WriteLine($"Marks  : {Marks}");
            Console.WriteLine();
        }
    }
}
