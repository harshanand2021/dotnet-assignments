﻿using System;
namespace Assignment5_2
{
	public class Circle:Shape
	{
        public override void Draw()
        {
            base.Draw();
            Console.WriteLine("Draw Circle");
        }
    }
}

