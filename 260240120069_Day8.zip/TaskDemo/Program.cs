﻿namespace TaskDemo
{
    internal class Program
    {
        static async Task DoWork()
        {
            Console.WriteLine("Task Started");

            await Task.Delay(3000); // Simulate some asynchronous work

            Console.WriteLine("Task Completed");
        }

        static async Task Main(string[] args)
        {
            Console.WriteLine("Main Started");

            await DoWork();

            Console.WriteLine("Main Completed");
        }
    }
}
