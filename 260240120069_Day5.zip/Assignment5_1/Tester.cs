﻿using System;
namespace Assignment5_1
{
	public class Tester:Employee
	{
        public string Tools { get; set; }

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine("Testing Tools : " + Tools);
        }
    }
}

