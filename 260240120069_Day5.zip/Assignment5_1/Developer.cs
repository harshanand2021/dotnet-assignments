﻿using System;
namespace Assignment5_1
{
	public class Developer : Employee
	{
		public string ProgrammingLanguage { get; set; }

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine("Programming Language : " + ProgrammingLanguage);
        }
    }
}

