﻿namespace Assignment5_2;

class Program
{
    static void Main(string[] args)
    {
        Shape shape1 = new Rectangle();
        Shape shape2 = new Triangle();
        Shape shape3 = new Circle();

        shape1.Draw();
        shape2.Draw();
        shape3.Draw();

    }
}

