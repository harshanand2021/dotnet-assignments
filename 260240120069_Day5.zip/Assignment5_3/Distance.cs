﻿using System;
namespace Assignment5_3
{
	public class Distance
	{
		public int Feet { get; set; }
		public int Inches { get; set; }

		public Distance(int feet, int inches)
		{
			Feet = feet;
			Inches = inches;
		}

		public static Distance operator +(Distance d1, Distance d2)
		{
			int feet = d1.Feet + d2.Feet;
			int inches = d1.Inches + d2.Inches;

			if(inches >= 12)
			{
				feet += inches / 12;
				inches = inches % 12;
			}

			return new Distance(feet, inches);
		}

		public void Display()
		{
			Console.WriteLine($"Feet : {Feet}, Inches : {Inches}");
		}
	}
}

