using Assignment8_2.Models;
using Microsoft.AspNetCore.Mvc;


namespace Assignment8_2.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
