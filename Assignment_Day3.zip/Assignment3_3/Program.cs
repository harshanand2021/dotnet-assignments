﻿namespace Assignment3_3;

class Program
{
    static int Main(string[] args)
    {
        Library library = new Library();

        // Setting books using indexer
        library[0] = "Harry Potter";
        library[1] = "The Hobbit";
        library[2] = "C# in Depth";
        library[3] = "OOP using Java";
        library[4] = "Algorithms and Data-Structures using Java";

        // Accessing books using indexer
        Console.WriteLine("Books in Library:");

        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"Book {i}: {library[i]}");
        }

        return 0;
    }
}

