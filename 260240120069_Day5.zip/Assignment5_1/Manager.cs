﻿using System;
namespace Assignment5_1
{
	public class Manager:Employee
	{
        public int TeamSize { get; set; }

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine("Team Size : " + TeamSize);
        }
    }
}

