﻿namespace Assignment3_2;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter a string: ");
        string MyString = Console.ReadLine();


        int WordCount = StringOperations.CountWords(MyString);

        Console.WriteLine("Words = " + WordCount);

        StringOperations.ToPascal(MyString);

        Console.WriteLine(StringOperations.ToPascal(MyString));

        string ReversedString = StringOperations.ReverseString(MyString);
        Console.WriteLine("Reversed String = " + ReversedString);
    }
}

