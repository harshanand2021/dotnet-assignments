﻿using System.ComponentModel.DataAnnotations;

namespace Assignment8_1
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Department { get; set; }

        public double Salary { get; set; }

    }
}
