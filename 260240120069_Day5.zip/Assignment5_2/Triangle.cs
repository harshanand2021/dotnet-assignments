﻿using System;
namespace Assignment5_2
{
	public class Triangle:Shape
	{
        public override void Draw()
        {
            base.Draw();
            Console.WriteLine("Draw Triangle");
        }
    }
}

