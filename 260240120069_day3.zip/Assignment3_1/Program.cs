﻿namespace Assignment3_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Ramu", "Singh", 36);

            person.DisplayAllDetails();

            if (person.IsAdult())
            {
                Console.WriteLine($"{person.GetFullName()} is an adult.");

            }
            else
            {
                Console.WriteLine($"{person.GetFullName()} is not an adult.");
            }
        }
    }
}
