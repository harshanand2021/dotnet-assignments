﻿using System;

namespace Assignment3_2
{
	public static class StringOperations
	{


		public static string ToPascal(this string s)
		{
			if (string.IsNullOrWhiteSpace(s))
				return string.Empty;

			string[] words = s.Split(' ', StringSplitOptions.RemoveEmptyEntries);

			for(int i=0; i<words.Length; i++)
			{
				words[i] = char.ToUpper(words[i][0]) + words[i].Substring(1).ToLower();
			}

			return string.Join("", words);
		}

		public static int CountWords(string s)
		{
			if (s == "" || s == null || s == " ")
				return 0;

			int WordCount = 0;

			for(int i=0; i<s.Length; i++)
			{
				WordCount += 1;
			}

			return WordCount;

		}

		public static string ReverseString(string s)
		{
			char[] StrArray = s.ToCharArray();

			Array.Reverse(StrArray);

			s = StrArray.ToString();

			return new string(s);
		}
	}
}

