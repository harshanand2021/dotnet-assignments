﻿using System;
namespace Assignment3_3
{

	public class Library
	{
        private string[] _books = new string[5];

        public string this[int index] //Indexer function
        {
            get
            {
                return _books[index];
            }
            set
            {
                _books[index] = value;
            }
        }
    }
}

