﻿using System;
namespace Assignment5_2
{
	public class Rectangle:Shape
	{
        public override void Draw()
        {
            base.Draw();
            Console.WriteLine("Draw Rectangle");
        }
    }
}

