﻿namespace Assignment2_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Instantiating and using the Student object
            Student student = new Student();
            student.RollNo = 101;
            student.Name = "Abhishek";
            student.Marks = 88.5;
            student.Display();

            // Instantiating and using the Person object
            Person person = new Person();
            person.PId = 1;
            person.PName = "Rahul";
            person.Mobile = "9876543210";
            person.DisplayPerson();

        }
    }
}
