﻿namespace Assignment5_3;

class Program
{
    static void Main(string[] args)
    {
        Distance distance1 = new Distance(5, 8);
        Distance distance2 = new Distance(7, 4);

        Distance sumDistance = distance1 + distance2;

        Console.Write("Distance1 = ");
        distance1.Display();

        Console.Write("Distance = ");
        distance2.Display();

        Console.Write("Total = ");
        sumDistance.Display();

        Console.WriteLine();


    }
}

