﻿using System;
namespace Assignment5_2
{
	public class Shape
	{
		public virtual void Draw()
		{
			Console.WriteLine("Draw Shape");
		}
	}
}

