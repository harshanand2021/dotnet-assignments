﻿using Microsoft.EntityFrameworkCore;

namespace Assignment8_1
{
    internal class AppDbContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                @"Server=SERVER_NAME;
                  Database=EmployeeDB
                  Trusted_Connection=True
                  TrustedServerCertificate=True"
                );

        }
    }
}
