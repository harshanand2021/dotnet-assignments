﻿using Assignment8_1;

AppDbContext context = new AppDbContext();

Employee employee1 = new Employee { Name = "John Doe", Department = "HR", Salary = 50000 };

context.Employees.Add(employee1);
context.SaveChanges();

Console.WriteLine("Employee Added..");