﻿using System;
using System.Xml.Linq;

namespace Assignment5_1
{
	public class Employee
	{
		public int EmployeeId { get; set; }
		public string EmployeeName { get; set; }
		public double BasicSalary { get; set; }

		public virtual void DisplayDetails()
		{
            Console.WriteLine("Employee ID   : " + EmployeeId);
            Console.WriteLine("Name          : " + EmployeeName);
            Console.WriteLine("Basic Salary  : " + BasicSalary);
        }
	}
}

