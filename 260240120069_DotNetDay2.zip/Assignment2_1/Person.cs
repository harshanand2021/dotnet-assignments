﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_1
{
    internal class Person
    {
        // Auto-implemented properties
        public int PId { get; set; }
        public string PName { get; set; }
        public string Mobile { get; set; }

        // DisplayPerson Method
        public void DisplayPerson()
        {
            Console.WriteLine($"--- Person Details ---");
            Console.WriteLine($"ID     : {PId}");
            Console.WriteLine($"Name   : {PName}");
            Console.WriteLine($"Mobile : {Mobile}");
            Console.WriteLine();
        }
    }
}
