﻿namespace Assignment8_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Thread thread = new Thread(() =>
            {
                for(int ind=0; ind <= 5; ind++)
                {
                    Console.WriteLine($"Thread {ind}");
                    Thread.Sleep(500);
                }
            });

            thread.Start();

            Console.WriteLine("Main Thread");
        }
    }
}
