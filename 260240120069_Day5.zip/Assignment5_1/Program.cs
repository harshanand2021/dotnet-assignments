﻿namespace Assignment5_1;

class Program
{
    static void Main(string[] args)
    {
        // Developer Object
        Developer dev = new Developer
        {
            EmployeeId = 101,
            EmployeeName = "Harsh",
            BasicSalary = 60000,
            ProgrammingLanguage = "C#"
        };

        // Manager Object
        Manager mgr = new Manager
        {
            EmployeeId = 102,
            EmployeeName = "Amit",
            BasicSalary = 85000,
            TeamSize = 12
        };

        // Tester Object
        Tester tester = new Tester
        {
            EmployeeId = 103,
            EmployeeName = "Sumit",
            BasicSalary = 50000,
            Tools = "Selenium"
        };

        Console.WriteLine("----- Developer Details -----");
        dev.DisplayDetails();

        Console.WriteLine("\n----- Manager Details -----");
        mgr.DisplayDetails();

        Console.WriteLine("\n----- Tester Details -----");
        tester.DisplayDetails();
    }
}

